package com.testcases;

public class test2 {
    public static void main(String args[])
{
    System.out.println("hello2");
}
}