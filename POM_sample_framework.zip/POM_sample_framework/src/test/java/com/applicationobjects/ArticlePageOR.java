package com.applicationobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ArticlePageOR {
    @FindBy(xpath = "//*[@id=\"wrapper\"]/footer/div/p[2]/a[1]")
    public WebElement lnk_ftrabout;

  

}
